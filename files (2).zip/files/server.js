// ============================================================
//  FILE: server.js  (FIXED)
//  PURPOSE: Express backend for the HR Attendance dashboard
//
//  ROOT CAUSE OF "Unexpected end of JSON input":
//    The old server was crashing inside the upload handler and
//    Express was sending an empty body (or HTML 500 page).
//    The browser's response.json() then threw because it got
//    nothing to parse. Every route now wraps its logic in
//    try/catch and always sends back valid JSON.
//
//  HOW TO RUN:
//    npm install express multer xlsx cors
//    node server.js
//    Open http://localhost:3000
//
//  EXCEL FORMAT EXPECTED (biometric machine export):
//    Sheet   : "Attendance" (or first sheet)
//    Columns : Employee ID | Employee Name | Department |
//              Date | Time | Punch Type
//    Time    : HH:MM  (24-hour)
//    Punch   : IN or OUT
//    Notes   : Multiple rows per employee per day are OK —
//              pipeline picks earliest IN / latest OUT
// ============================================================

'use strict';

const express = require('express');
const multer  = require('multer');
const XLSX    = require('xlsx');
const cors    = require('cors');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
// Serve all static files from project folder (index.html, app.js, app_.js, etc.)
app.use(express.static(path.join(__dirname)));

// Multer: keep file in memory, accept only xlsx/xls, max 20 MB
const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (/\.(xlsx|xls)$/i.test(file.originalname)) {
      cb(null, true);
    } else {
      cb(new Error('Only .xlsx or .xls files are accepted'), false);
    }
  },
});

// ── In-memory store (replace with DB/Sheets calls later) ──────
let employeeMap  = {};   // { [empId]: employee object }
let alerts       = [];   // generated alert messages (max 50)
let trendCounts  = [0,0,0,0,0,0,0];  // Mon–Sun late counts

// ── Helpers ───────────────────────────────────────────────────
function to12hr(t) {
  if (!t) return null;
  const parts = String(t).trim().split(':');
  let h = parseInt(parts[0], 10);
  const m = (parts[1] || '00').slice(0, 2);
  const ampm = h >= 12 ? 'PM' : 'AM';
  if (h > 12) h -= 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${ampm}`;
}

function isLate(timeStr) {
  if (!timeStr) return false;
  return String(timeStr).trim() > '11:00';
}

function dayIndex(dateStr) {
  const jsDay = new Date(dateStr).getDay();   // 0=Sun … 6=Sat
  return jsDay === 0 ? 6 : jsDay - 1;         // Mon=0 … Sun=6
}

// Always send a JSON error — never send empty body or HTML
function sendError(res, status, msg) {
  return res.status(status).json({ error: msg });
}

// ── Core: process an Excel Buffer ─────────────────────────────
function processExcelBuffer(buffer) {

  // 1. Parse workbook
  let wb;
  try {
    wb = XLSX.read(buffer, { type: 'buffer', cellDates: false });
  } catch (e) {
    throw new Error('Cannot parse Excel file: ' + e.message);
  }

  // 2. Pick sheet
  const sheetName = wb.SheetNames.includes('Attendance')
    ? 'Attendance'
    : wb.SheetNames[0];
  if (!sheetName) throw new Error('Excel file has no sheets');

  const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], { defval: '' });
  if (!rows.length) throw new Error('Sheet "' + sheetName + '" has no data rows');

  // 3. Auto-detect column names (case/space/underscore insensitive)
  const COL = {};
  for (const k of Object.keys(rows[0])) {
    const n = k.toLowerCase().replace(/[\s_\-]/g, '');
    if (n.includes('employeeid') || n === 'id')           COL.id   = k;
    if (n.includes('employeename') || n === 'name')       COL.name = k;
    if (n.includes('department') || n === 'dept')         COL.dept = k;
    if (n === 'date')                                      COL.date = k;
    if (n === 'time')                                      COL.time = k;
    if (n.includes('punch') || n.includes('type'))        COL.type = k;
  }
  const missing = ['id','name','dept','date','time','type'].filter(c => !COL[c]);
  if (missing.length) {
    throw new Error(
      'Missing columns: ' + missing.join(', ') +
      '. Found: ' + Object.keys(rows[0]).join(', ')
    );
  }

  // 4. Group punches by Employee + Date
  const groups = {};
  let skipped  = 0;

  for (const row of rows) {
    const id   = String(row[COL.id]   || '').trim();
    const name = String(row[COL.name] || '').trim();
    const dept = String(row[COL.dept] || '').trim();
    const date = String(row[COL.date] || '').trim();
    const time = String(row[COL.time] || '').trim();
    const type = String(row[COL.type] || '').trim().toUpperCase();

    if (!id || !date || !time || !['IN','OUT'].includes(type)) {
      skipped++;
      continue;
    }

    const key = id + '|' + date;
    if (!groups[key]) groups[key] = { id, name, dept, date, ins: [], outs: [] };
    if (type === 'IN')  groups[key].ins.push(time);
    if (type === 'OUT') groups[key].outs.push(time);
  }

  // 5. Apply Earliest-IN / Latest-OUT logic  (Step 2 of n8n pipeline)
  let processed = 0;

  for (const g of Object.values(groups)) {
    const checkInRaw  = g.ins.length  ? g.ins.sort()[0]             : null;
    const checkOutRaw = g.outs.length ? g.outs.sort().slice(-1)[0]  : null;
    const late        = isLate(checkInRaw);
    const checkIn     = to12hr(checkInRaw);
    const checkOut    = to12hr(checkOutRaw);

    // Upsert employee record
    if (!employeeMap[g.id]) {
      employeeMap[g.id] = {
        id: g.id, name: g.name, dept: g.dept,
        email:     g.id.toLowerCase().replace(/[^a-z0-9]/g, '') + '@company.com',
        checkIn:   null, checkOut: null,
        late:      false, lateCount: 0,
        excused:   false, photo: null,
      };
    }

    const emp    = employeeMap[g.id];
    const wasLate = emp.late;

    emp.checkIn  = checkIn;
    emp.checkOut = checkOut;
    emp.late     = late;

    // Only add a strike if today's status changed to late
    if (late && !wasLate && !emp.excused) {
      emp.lateCount++;

      const di = dayIndex(g.date);
      if (di >= 0 && di < 7) trendCounts[di]++;

      // Build alert message
      const now = new Date().toLocaleTimeString('en-IN', {
        hour: '2-digit', minute: '2-digit', hour12: false,
      });

      if (emp.lateCount >= 3) {
        // Step 4: Google Calendar hook — book 5 PM meeting on 3rd strike
        // createCalendarEvent(emp.name, g.date);   ← uncomment when configured

        alerts.unshift({
          name:  emp.name,
          msg:   emp.name + ' hit 3 strikes. HR meeting booked at 5:00 PM.',
          level: 'critical',
          time:  now,
        });
      } else if (emp.lateCount === 2) {
        alerts.unshift({
          name:  emp.name,
          msg:   emp.name + ' is at 2 strikes — 1 more triggers a mandatory meeting.',
          level: 'warning',
          time:  now,
        });
      }

      if (alerts.length > 50) alerts = alerts.slice(0, 50);
    }

    processed++;
  }

  return { processed, skipped };
}

// ── Google Calendar stub (Step 4 of pipeline) ─────────────────
// Uncomment + install googleapis + set env vars to enable:
//
// async function createCalendarEvent(empName, dateStr) {
//   const { google } = require('googleapis');
//   const auth = new google.auth.JWT(
//     process.env.GOOGLE_CLIENT_EMAIL, null,
//     process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g,'\n'),
//     ['https://www.googleapis.com/auth/calendar']
//   );
//   const cal = google.calendar({ version: 'v3', auth });
//   await cal.events.insert({
//     calendarId: 'primary',
//     requestBody: {
//       summary:     `HR Meeting – ${empName}`,
//       description: '3rd late strike — mandatory HR review.',
//       start: { dateTime: `${dateStr}T17:00:00`, timeZone: 'Asia/Kolkata' },
//       end:   { dateTime: `${dateStr}T17:30:00`, timeZone: 'Asia/Kolkata' },
//     },
//   });
// }


// ════════════════════════════════════════════════════════════
//  ROUTES — every single one returns JSON, never empty body
// ════════════════════════════════════════════════════════════

// GET /api/employees
app.get('/api/employees', (_req, res) => {
  try {
    res.json(Object.values(employeeMap));
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

// GET /api/dashboard
app.get('/api/dashboard', (_req, res) => {
  try {
    const data = {
      totalEmployees: Object.keys(employeeMap).length,
      onTime:         Object.values(employeeMap).filter(e => !e.late).length,
      lateToday:      Object.values(employeeMap).filter(e => e.late && !e.excused).length,
      critical:       Object.values(employeeMap).filter(e => e.lateCount >= 3).length,
      trend:          trendCounts.map((count, i) => ({ day: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i], count })),
      monthly:        Object.values(employeeMap).map(e => ({
                        id:        e.id,
                        name:      e.name,
                        dept:      e.dept,
                        lateCount: e.lateCount,
                        late:      e.late ? 'YES' : 'NO',
                        excused:   e.excused,
                        checkIn:   e.checkIn,
                        checkOut:  e.checkOut,
                        photo:     e.photo || null,
                      })),
      alerts:         alerts,
    };
    res.json(data);
  } catch (err) {
    sendError(res, 500, err.message);
  }
});

// POST /api/upload-excel  ← THIS IS WHERE THE BUG WAS
app.post('/api/upload-excel', (req, res) => {

  // Run multer manually so its errors also return JSON, not a crash
  upload.single('file')(req, res, (multerErr) => {

    // Multer error (wrong file type, too large, etc.)
    if (multerErr) {
      return sendError(res, 400, multerErr.message);
    }

    // No file attached
    if (!req.file) {
      return sendError(res, 400, 'No file received. The form field must be named "file".');
    }

    // Process the buffer — wrap in try/catch so crashes → JSON error
    let result;
    try {
      result = processExcelBuffer(req.file.buffer);
    } catch (e) {
      return sendError(res, 422, e.message);
    }

    // Success — always return JSON
    return res.json({
      success:   true,
      processed: result.processed,
      skipped:   result.skipped,
      message:   `Processed ${result.processed} records (${result.skipped} skipped).`,
    });
  });
});

// POST /api/mark-attendance
app.post('/api/mark-attendance', (req, res) => {
  try {
    const { employeeId, photo, punchStatus } = req.body;
    if (!employeeId) return sendError(res, 400, 'employeeId is required');

    const emp = employeeMap[employeeId];
    if (!emp) return sendError(res, 404, 'Employee not found: ' + employeeId);

    const now     = new Date();
    const hh      = String(now.getHours()).padStart(2,'0');
    const mm      = String(now.getMinutes()).padStart(2,'0');
    const timeStr = hh + ':' + mm;
    const late    = timeStr > '11:00';

    if (punchStatus === 'IN') {
      emp.checkIn = to12hr(timeStr);
      emp.late    = late;
      if (photo) emp.photo = photo;
      if (late && !emp.excused) {
        emp.lateCount++;
        const di = dayIndex(now.toISOString().slice(0,10));
        if (di >= 0 && di < 7) trendCounts[di]++;
      }
    } else {
      emp.checkOut = to12hr(timeStr);
    }

    res.json({ success: true, record: { ...emp, late: emp.late ? 'YES' : 'NO' } });
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

// POST /api/excuse
app.post('/api/excuse', (req, res) => {
  try {
    const { employeeId } = req.body;
    if (!employeeId) return sendError(res, 400, 'employeeId is required');

    const emp = employeeMap[employeeId];
    if (!emp) return sendError(res, 404, 'Employee not found: ' + employeeId);

    emp.excused = !emp.excused;
    res.json({ success: true, employeeId, excused: emp.excused });
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

// GET /api/download-excel
app.get('/api/download-excel', (_req, res) => {
  try {
    const rows = Object.values(employeeMap).map(e => ({
      'Employee ID': e.id,
      'Name':        e.name,
      'Department':  e.dept,
      'Check-In':    e.checkIn  || '—',
      'Check-Out':   e.checkOut || '—',
      'Late Today':  e.late     ? 'YES' : 'NO',
      'Late Count':  e.lateCount,
      'Status':      e.lateCount >= 3 ? 'Critical' : e.lateCount >= 2 ? 'At Risk' : 'Safe',
      'Excused':     e.excused  ? 'YES' : 'NO',
    }));

    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Note: 'No data yet' }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Attendance');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Disposition', 'attachment; filename="attendance_export.xlsx"');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (e) {
    sendError(res, 500, e.message);
  }
});

// Catch-all for unknown /api/* routes
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) return sendError(res, 404, 'Route not found: ' + req.path);
  next();
});

// SPA fallback — serve index.html (handles both index.html and index_.html)
app.use((_req, res) => {
  const fs = require('fs');
  // Support both filename variants
  const candidates = ['index.html', 'index_.html'];
  for (const name of candidates) {
    const full = path.join(__dirname, name);
    if (fs.existsSync(full)) return res.sendFile(full);
  }
  res.status(404).send('index.html not found in: ' + __dirname);
});

// Global error handler — MUST have 4 params for Express to use it
// This is the final safety net so the server NEVER sends empty body
app.use((err, _req, res, _next) => {
  console.error('[unhandled error]', err);
  if (!res.headersSent) sendError(res, 500, err.message || 'Internal server error');
});

// ── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  const fs   = require('fs');
  const files = ['index.html','index_.html','app.js','app_.js','dashboard.html','dashboard.js'];

  console.log('\n✓  HR Attendance server running at http://localhost:' + PORT);
  console.log('   Dashboard API  →  http://localhost:' + PORT + '/api/dashboard');
  console.log('   Upload API     →  POST http://localhost:' + PORT + '/api/upload-excel');
  console.log('\n   Files found in', __dirname + ':');
  files.forEach(f => {
    const exists = fs.existsSync(path.join(__dirname, f));
    console.log('   ' + (exists ? '✓' : '✗ MISSING') + '  ' + f);
  });
  console.log('');
});
